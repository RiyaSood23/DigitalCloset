//
//  SwiftUIView.swift
//  DigitalCloset
//
//  Created by Student on 25/02/26.
//

import SwiftUI

struct OccasionCardView: View {
    
    let occasion: OccasionModel
    
    var body: some View {
        VStack(spacing: 8) {
            Image(occasion.imageName)
                .resizable()
                .scaledToFill()
                .frame(height: 110)
                .clipped()
                .cornerRadius(14)

            Text(occasion.rawValue)
                .font(.subheadline)
                .fontWeight(.medium)
        }
        .frame(maxWidth: .infinity)
    }
}

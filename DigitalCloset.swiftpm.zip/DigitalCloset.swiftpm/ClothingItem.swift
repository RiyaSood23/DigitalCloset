//
//  SwiftUIView.swift
//  DigitalCloset
//
//  Created by Student on 25/02/26.
//

import Foundation

struct ClothingItem: Identifiable {
    let id = UUID()
    let name: String
    let imageName: String
    let category: String
    let style: String
    let lastWornDate: String
    var isFavorite: Bool
}

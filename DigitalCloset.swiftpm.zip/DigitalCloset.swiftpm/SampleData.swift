//
//  SwiftUIView.swift
//  DigitalCloset
//
//  Created by Student on 25/02/26.
//

let sampleClothes: [ClothingItem] = [
    ClothingItem(
        name: "Red Crop Top",
        imageName: "top1",
        category: "Tops",
        style: "Party",
        lastWornDate: "12 Feb 2025",
        isFavorite: false
    ),
    ClothingItem(
        name: "White Basic Tee",
        imageName: "top2",
        category: "Tops",
        style: "Casual",
        lastWornDate: "3 Jan 2025",
        isFavorite: true
    ),
    ClothingItem(
        name: "Black Satin Top",
        imageName: "top3",
        category: "Tops",
        style: "Formal",
        lastWornDate: "Never",
        isFavorite: false
    ),
    ClothingItem(
        name: "Blue Oversized Shirt",
        imageName: "top4",
        category: "Tops",
        style: "College",
        lastWornDate: "20 Feb 2025",
        isFavorite: false
    )
]

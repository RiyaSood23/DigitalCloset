//
//  SwiftUIView.swift
//  DigitalCloset
//
//  Created by Student on 25/02/26.
//

import SwiftUI

struct CategoryView: View {
    
    let title: String
    
    var body: some View {
        VStack {
            Text(title)
                .font(.largeTitle)
                .bold()
            
            Spacer()
        }
        .navigationTitle(title)
        .padding()
    }
}

#Preview {
    NavigationStack {
        CategoryView(title: "Tops")
    }
}


import SwiftUI

@main
struct DigitalClosetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

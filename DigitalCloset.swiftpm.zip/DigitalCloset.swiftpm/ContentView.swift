import SwiftUI

struct ContentView: View {
    
    let categories = [
        "Tops",
        "Dresses",
        "Jeans",
        "Skirts",
        "Pants",
        "Nightwear",
        "Miscellaneous"
    ]
    
    let occasions = [
        "Party",
        "Formal",
        "College",
        "Concert",
        "Casual",
        "Travel"
    ]
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    
                    // Title
                    Text("✨ Your Dream Closet")
                        .font(.largeTitle)
                        .bold()
                    
                    // MARK: Categories Section
                    Text("Categories")
                        .font(.title2)
                        .bold()
                    
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(categories, id: \.self) { category in
                            VStack(spacing: 8) {
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(height: 120)
                                
                                Text(category)
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                            }
                        }
                    }
                    
                    // MARK: Occasions Section
                    Text("Occasions")
                        .font(.title2)
                        .bold()
                    
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(occasions, id: \.self) { occasion in
                            VStack(spacing: 8) {
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(height: 120)
                                
                                Text(occasion)
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                            }
                        }
                    }
                    
                }
                .padding()
            }
        }
    }
}

#Preview {
    ContentView()
}

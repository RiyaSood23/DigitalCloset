//
//  SwiftUIView.swift
//  DigitalCloset
//
//  Created by Student on 25/02/26.
//

import Foundation

enum OccasionModel: String, CaseIterable, Identifiable {
    case party = "Party"
    case formal = "Formal"
    case college = "College"
    case concert = "Concert"
    case casual = "Casual"
    case travel = "Travel"

    var id: String { rawValue }

    var imageName: String {
        switch self {
        case .party: return "party"
        case .formal: return "formal"
        case .college: return "college"
        case .concert: return "concert"
        case .casual: return "casual"
        case .travel: return "travel"
        }
    }
}

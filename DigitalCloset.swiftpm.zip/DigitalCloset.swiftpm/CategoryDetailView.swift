//
//  CategoryDetailView.swift
//  DigitalCloset
//
//  Created by Student on 25/02/26.
//


import SwiftUI

struct CategoryDetailView: View {
    
    @State private var clothes = sampleClothes
    
    let category: String
    
    var filteredItems: [ClothingItem] {
        clothes.filter { $0.category == category }
    }
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                
                ForEach(filteredItems.indices, id: \.self) { index in
                    let item = filteredItems[index]
                    
                    VStack(alignment: .leading, spacing: 6) {
                        
                        ZStack(alignment: .topTrailing) {
                            
                            Image(item.imageName)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 130)
                                .clipped()
                                .cornerRadius(12)
                            
                            Button {
                                toggleFavorite(for: item)
                            } label: {
                                Image(systemName: item.isFavorite ? "star.fill" : "star")
                                    .foregroundColor(.yellow)
                                    .padding(8)
                                    .background(.ultraThinMaterial)
                                    .clipShape(Circle())
                                    .padding(6)
                            }
                        }
                        
                        Text(item.name)
                            .font(.headline)
                        
                        Text("\(item.style) • \(item.category)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        
                        Text("Last worn: \(item.lastWornDate)")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding()
        }
        .navigationTitle(category)
    }
    
    private func toggleFavorite(for item: ClothingItem) {
        if let index = clothes.firstIndex(where: { $0.id == item.id }) {
            clothes[index].isFavorite.toggle()
        }
    }
}